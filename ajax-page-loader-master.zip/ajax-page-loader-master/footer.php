<?php

if (!$content_only) {

?>
    </main>
    <footer>
        Made with love
    </footer>
    <script src="page-load.js"></script>
</body>
</html>
<?php

}
