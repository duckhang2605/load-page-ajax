# AJAX Page Loader

Dynamically load webpages with `XMLHttpRequest`s.

[Video Guide](https://youtu.be/ELxmUJZhyV8)
