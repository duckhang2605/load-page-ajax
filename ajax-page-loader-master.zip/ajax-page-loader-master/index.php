<?php

$page_title = 'Main page';

include 'header.php';

?>

<h1>
    Main page
</h1>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    <a href="./">Home</a>
    <a href="./about.php">About</a>
    <a href="./contact.php">Contact</a>
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, animi, quis. Sapiente cupiditate, itaque perferendis pariatur fuga non illum debitis, ex, aliquam nostrum velit animi deserunt libero tenetur veritatis accusamus!
</p>

<?php

include 'footer.php';

?>
